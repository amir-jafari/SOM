import numpy as np
import matplotlib.pyplot as plt
import pickle
from scipy.spatial.distance import cdist
from sklearn.datasets import load_iris
import os
# Load the Iris dataset
iris = load_iris()
X = iris.data  # Features
y = iris.target  # Target labels

# Set parameters
SOM_Row_Num = 4
model_path = os.getcwd() + os.sep

# Read trained SOM model
Trained_SOM_File = model_path + "SOM_Model_titanic.pkl"
with open(Trained_SOM_File, "rb") as file:
    som_net = pickle.load(file)

# Compute statistics
ww = som_net.w
x_w_dist = cdist(ww, X, 'euclidean')
ind1 = np.argmin(x_w_dist, axis=0)

S = som_net.w.shape[0]
Q = X.shape[1]

Clust = []
dist = []
tp = [[] for _ in range(3)]
fp = [[] for _ in range(3)]
fn = [[] for _ in range(3)]
tn = [[] for _ in range(3)]
Perc_pos = np.zeros((3, S))
Perc_neg = np.zeros((3, S))
num_pos = np.zeros((3, S))
tp_n = np.zeros((3, S))
fp_n = np.zeros((3, S))
fn_n = np.zeros((3, S))
tn_n = np.zeros((3, S))
cats_n = np.zeros((3, S))
mdist = np.zeros(S)
clustSize = []

for i in range(S):
    tempclust = np.where(ind1 == i)[0]
    tempdist = x_w_dist[i, tempclust]
    indsort = np.argsort(tempdist)
    tempclust = tempclust[indsort]
    tempdist = tempdist[indsort]

    dist.append(tempdist)
    Clust.append(tempclust)

    num = len(tempclust)
    clustSize.append(num)

    if num > 0:
        mdist[i] = tempdist[-1]

    for cati in range(3):  # Adjusted for 3 classes in Iris dataset
        fpos = np.intersect1d(tempclust, np.where(y != cati)[0])
        fp[cati].append(fpos)
        fp_n[cati][i] = len(fpos)

        fneg = np.intersect1d(tempclust, np.where(y == cati)[0])
        fn[cati].append(fneg)
        fn_n[cati][i] = len(fneg)

        temp = np.union1d(fp[cati][i], fn[cati][i])
        temp = np.setdiff1d(tempclust, temp)
        tpos = np.intersect1d(temp, np.where(y == cati)[0])
        tp[cati].append(tpos)
        tp_n[cati][i] = len(tpos)

        tneg = np.intersect1d(temp, np.where(y != cati)[0])
        tn[cati].append(tneg)
        tn_n[cati][i] = len(tneg)

        cats_n[cati][i] = len(np.intersect1d(tempclust, np.where(y == cati)[0]))

    if num != 0:
        num = float(num)
        for cati in range(3):
            num_pos[cati][i] = len(np.intersect1d(tempclust, np.where(y == cati)[0]))
            Perc_pos[cati][i] = 100 * len(np.intersect1d(tempclust, np.where(y == cati)[0])) / num
            Perc_neg[cati][i] = 100 * len(np.intersect1d(tempclust, np.where(y != cati)[0])) / num
    else:
        print('Num = 0, i = ' + str(i))

quant_err = np.array([0 if len(item) == 0 else np.mean(item) for item in dist]).mean()
print('Quantization error = ' + str(quant_err))

ndist = som_net.neuron_dist
sort_dist = np.argsort(x_w_dist, axis=0)
top_dist = [ndist[sort_dist[0, ii], sort_dist[1, ii]] for ii in range(sort_dist.shape[1])]
neighbors = np.where(np.array(top_dist) > 1.1)
top_error = 100 * len(neighbors[0]) / x_w_dist.shape[1]
print('Topological Error (1st neighbor) = ' + str(top_error) + '%')
neighbors = np.where(np.array(top_dist) > 2.1)
top_error = 100 * len(neighbors[0]) / x_w_dist.shape[1]
print('Topological Error (1st and 2nd neighbor) = ' + str(top_error) + '%')

dd = [1, 2, 3]  # neighborhood distances
wwdist = cdist(ww, ww, 'euclidean')
sst = ndist[:, ind1]
for d in dd:
    factor1 = 2 * d * d
    factor2 = Q * d * np.sqrt(2 * np.pi)
    temp = np.exp(-np.multiply(sst, sst) / factor1)
    distortion = np.sum(np.multiply(temp, x_w_dist)) / factor2
    print('Distortion (d=' + str(d) + ') = ' + str(distortion))

# input_data_points_in_clusters = []
# for i in range(len(Clust)):
#     cluster_indices = Clust[i]  # Indices of input data points in cluster i
#     input_data_points = X[:, cluster_indices]  # Input data points in cluster i
#     input_data_points_in_clusters.append(input_data_points)

# Plot histograms
#fig0, ax0, patch0 = som_net.plt_hist(input_data_points_in_clusters)
#plt.show()

# Plot category distribution
fig0, ax0, patch0 = som_net.plt_dist(cats_n.transpose())
plt.show()

# Plot topology
fig0, ax0, patch0, text0 = som_net.plt_top_num()
plt.title('SOM Topology')
plt.show()

# Plot hit histogram
fig4, ax4, patch4, text4 = som_net.hit_hist(X, True)
plt.show()

# Plot distances between clusters
fig55, ax55, patch55 = som_net.neuron_dist_plot()
plt.title('SOM Neighbor Weight Distances', fontsize=16)
plt.show()

# Plot color code for maximum distance of each cluster
fig51, ax51, patches51, cbar51 = som_net.simple_grid(mdist, net_ones)
plt.title('Maximum radius for each cluster', fontsize=16)
plt.show()

Category = ['Setosa', 'Versicolor', 'Virginica']

for i in range(3):
    Title = ''
    fig2, ax2, handles2 = som_net.plt_pie(Title, same_size, tp_n[i], fn_n[i], tn_n[i], fp_n[i])
    plt.show()

for i in range(3):
    fig2, ax2, handles2, cbar2 = som_net.simple_grid(fp_n[i], net_ones)
    plt.show()

for i in range(3):
    fig5, ax5, patches5, cbar5 = som_net.simple_grid(Perc_pos[i], net_ones)
    plt.title('Percent Positive, Category ' + Category[i], fontsize=16)
    plt.show()