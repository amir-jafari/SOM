print('test')
print()