class PlotSOM():
    pass