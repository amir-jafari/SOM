class PlotSOM():
    pass