print('test')
print()